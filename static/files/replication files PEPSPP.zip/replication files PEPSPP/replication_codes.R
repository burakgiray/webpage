library(tidyverse)
library(countrycode)
library(readr)
library(readxl)
library(ggplot2)
library(ggcorrplot)
library(readxl)
library(stargazer)
library(sandwich)
library(lmtest)
library(AER)
library(MASS)
library(readxl)

#### Figure 1:
fatalities <- read_csv("odp_noticas.csv", 
                       col_types = cols(Incident_Date = col_date(format = "%m/%d/%Y"))) %>% filter(Mission_Acronym == "MONUSCO")

pko_sentiment <- read_csv("pko_sentiment.csv") 
                       

fatalities$month<- strftime(fatalities$Incident_Date,"%m")
fatalities$year<- strftime(fatalities$Incident_Date,"%Y")

fatalities$date <- paste(
  fatalities$year,
  fatalities$month,
  "01",
  sep = "-"
) %>%
  as.Date()


count_df <- fatalities %>%
  group_by(
    Type_Of_Incident,
    #    Casualty_Nationality,
    date,
    Mission_Acronym
  ) %>%
  count() %>%
  data.frame() %>%
  pivot_wider(
    names_from  = "Type_Of_Incident", values_from = "n")

pko_sentiment_date = pko_sentiment %>% select(date)
pko_sentiment$log_lag_totalviolence = log(pko_sentiment$lag_totalviolence)
pko_sentiment$year  = strftime(pko_sentiment$date,"%Y")

count_df <- merge(
  count_df,
  pko_sentiment_date,
  by.x  = c(
    "date"
  ),
  by.y  = c(
    "date"
  ),
  all.x = TRUE,
  all.y =TRUE
) %>% replace(is.na(.), 0) %>% mutate(pkofatality = rowSums(across(where(is.numeric))))

count_df =count_df %>% filter(date >= "2014-01-01" & date < "2021-01-01")
monusco_df =count_df %>% filter(Mission_Acronym == "MONUSCO")

ggplot(data=monusco_df, aes(x=date, y=pkofatality)) +
  geom_bar(stat="identity") + ylab("Peacekeepers' Fatality in MONUSCO") +xlab("")

#### Table 1:

fatality3 <- glm.nb(
  pkofatality ~
    trustratio +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #  propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment,
  control = glm.control(maxit = 100)
)
stargazer(fatality3, type="text")


fatality4 <- glm.nb(
  pkofatality ~
    lag_pkofatality +
    trustratio +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #    propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment,
  control = glm.control(maxit = 100)
)


stargazer(fatality3, fatality4,fatality3, fatality4, no.space = TRUE, type="text")
coeftest(fatality3, vcov = vcovCL(fatality3, cluster = pko_sentiment$year))
coeftest(fatality4, vcov = vcovCL(fatality4, cluster = pko_sentiment$year))

# The last two columns of stargazer table will be replaced by the results in coeftest.

#### Figure 2:

newdata<-data.frame(trustratio=seq(0.00, 0.50,length=8),
                    logtroop=mean(pko_sentiment$logtroop),
                    logpolice=mean(pko_sentiment$logpolice),
                    logmilitaryobservers=mean(pko_sentiment$logmilitaryobservers),
                    totalTCC=mean(pko_sentiment$totalTCC),
                    propdemoc=mean(pko_sentiment$propdemoc),
                    log_lag_totalviolence=mean(pko_sentiment$log_lag_totalviolence),
                    tsince=mean(pko_sentiment$tsince))

# Mean predictions and SEs.
newdata1<- cbind(newdata,predict(fatality3, newdata, type = "response",se.fit=TRUE))
# Adding CIs

# 1.645 is for 90 percent confidence interval

newdata1 <- within(newdata1, {
  LL <- fit - 1.645 * se.fit
  UL <- fit + 1.645 * se.fit
  meancounts <- fit
})
# Plot predicted counts with CIs.
ggplot(newdata1,aes(x=trustratio,y=meancounts))+
  geom_point(color="black")+
  geom_errorbar(aes(ymin=LL,ymax=UL),color="black",size=0.7,width=0.1)+
  theme_gray()+
  labs(x="Positive Sentiments",y="Predicted Counts of Attacks \n on Peacekeepers")

#### Figure A4:

ggplot(pko_sentiment, aes(x = date, y = trustratio)) +
  geom_line(size = 0.7) +
  labs(x = "",
       y = "Ratio of Trust Sentiments")+
  scale_x_date(breaks = scales::breaks_pretty(15))+
  theme(axis.text.x = element_text(angle = 75, vjust = 0.5, hjust=1))


#### Figure A5 (Negative vs. Positive Plot):

colors <- c("Positive Sentiments" = "steelblue", "Negative Sentiments" = "darkred")

ggplot(pko_sentiment, aes(x = date)) +
  geom_line(aes(y = positiveratio, color = "Positive Sentiments"), size = 0.7) +
  geom_line(aes(y = negativeratio, color = "Negative Sentiments"), size = 0.7) +
  labs(x = "",
       y = "Ratio of Positive and Negative Sentiments",
       color = "") +
  theme(legend.position = c(0.85, 0.85))+
  scale_color_manual(values = colors)+   scale_x_date(breaks = scales::breaks_pretty(15))+
  theme(axis.text.x = element_text(angle = 75, vjust = 0.5, hjust=1))

#### Figure A6:

survey_data <- read_excel("survey_data.xlsx", 
                          col_types = c("date", "numeric", "numeric", 
                                        "numeric","numeric"))

colors2 <- c("Survey data" = "steelblue", "Twitter data" = "darkred")

ggplot(survey_data, aes(x = date)) +
  geom_smooth(aes(y = survey, color = "Survey data"), span = 0.3) +
  geom_smooth(aes(y = trustratio2, color = "Twitter data"), span = 0.3) +
  labs(x = "",
       y = "% Trust to MONUSCO:\n Survey data vs. Twitter data",
       color = "") +
  theme(legend.position = c(0.85, 0.85))+
  scale_color_manual(values = colors2)


#### Table B1:

nested = pko_sentiment %>% filter(date != "2017-12-01")

outlier1 <- glm(
  pkofatality ~
    trustratio +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #   propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = nested,
  family = "poisson"
)

outlier2 <- glm(
  pkofatality ~
    lag_pkofatality +
    trustratio +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #  propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = nested,
  family = "poisson"
) 


dispersiontest(outlier1, trafo = 1) # alpha lower than 1, no overdispersion
dispersiontest(outlier2, trafo  = 1) # alpha lower than 1, no overdispersion

coeftest(outlier1, vcov = vcovCL(outlier1, cluster = nested$year))
coeftest(outlier2, vcov = vcovCL(outlier2, cluster = nested$year))

stargazer(outlier1, outlier2,outlier1, outlier2, no.space = TRUE, type="text")
# The last two columns of stargazer table will be replaced by the results in coeftest.

#### Table B2:

overfitting1 <- glm.nb(
  pkofatality ~
    trustratio +
    logtotal+
    totalTCC +
    #  propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment,
  control = glm.control(maxit = 100)
)


overfitting2 <- glm.nb(
  pkofatality ~
    lag_pkofatality +
    trustratio +
    logtotal+
    totalTCC +
    #    propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment,
  control = glm.control(maxit = 100)
)

stargazer(overfitting1, overfitting2, overfitting1, overfitting2,no.space = TRUE, type="text")

coeftest(overfitting1, vcov = vcovCL(overfitting1, cluster = pko_sentiment$year))
coeftest(overfitting2, vcov = vcovCL(overfitting2, cluster = pko_sentiment$year))

# The last two columns of stargazer table will be replaced by the results in coeftest.

#### Table B3:

reversed1 <- lm(
  trustratio ~
    lag_pkofatality +
    logtotal +
    #  logpolice +
    #  logmilitaryobservers +
    totalTCC +
    #  propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment)

reversed2 <- lm(
  trustratio ~
    lag_pkofatality +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #  propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment)

stargazer(reversed2, type="text")
stargazer(reversed1,reversed2, reversed1, reversed2, no.space = TRUE,type="text")
coeftest(reversed1, vcov = vcovCL(reversed1, cluster = pko_sentiment$year))
coeftest(reversed2, vcov = vcovCL(reversed2, cluster = pko_sentiment$year))

# The last two columns of stargazer table will be replaced by the results in coeftest.

#### Table B4:

fatality1 <- glm.nb(
  pkofatality ~
    angerratio +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #   propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment,
  control = glm.control(maxit = 100)
)

fatality2 <- glm.nb(
  pkofatality ~
    lag_pkofatality +
    angerratio +
    logtroop +
    logpolice +
    logmilitaryobservers +
    totalTCC +
    #   propdemoc+
    log_lag_totalviolence+
    tsince,
  data   = pko_sentiment,
  control = glm.control(maxit = 100)
)

stargazer(fatality1, fatality2,fatality1, fatality2, no.space = TRUE, type="text")
coeftest(fatality1, vcov = vcovCL(fatality1, cluster = pko_sentiment$year)) #!
coeftest(fatality2, vcov = vcovCL(fatality2, cluster = pko_sentiment$year)) #!

# The last two columns of stargazer table will be replaced by the results in coeftest.


