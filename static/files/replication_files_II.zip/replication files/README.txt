

Author: Burak GirayEmail: bgiray@uh.eduSoftware used: RStudio version 1.4.1717Main replication code: - commitment_to_un_peacekeeping.RMain replication files: - mydata.csv- duration_mydata.csvAuxiliary replication file:- PKOivc.csv