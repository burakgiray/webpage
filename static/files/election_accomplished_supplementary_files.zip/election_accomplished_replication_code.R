###########################################################
# This file contains code to replicate                    #
# all tables and figures in:                              #
#                                                         #
# "Election Accomplished: Democracies and the Timing of   #
# Peacekeeper Drawdowns"                                  #
#                                                         #
# By: Burak Giray and J. Tyson Chatagnier                 #
#                                                         #
# Forthcoming in Political Research Quarterly             #
#                                                         #
# File created 4 July 2023                                #
###########################################################

library(texreg)
library(plm)
library(fixest)
library(marginaleffects)
library(readr)
library(tidyverse)
library(gridExtra)

rm(list = ls())

setwd("C:/Dropbox/peacekeeping data/PRQ_Data_Submission")



######################
# Relevant functions #
######################

PlotTrend <- function(
  data,
  period,
  var,
  type    = c(
              "smoothed",
              "spline"
              ),
  ret_mod = FALSE
  ) {
  quo_var <- enquo(var)
  comp_df <- data %>%
    filter(
           t >= -period &
           t <= period &
           !is.na(treat_democ)
           ) %>%
      select(
             Mission_aggregated,
             Contributor,
             date,
             treat_democ,
             !! quo_var,
             t
             ) %>%
        group_by(
                 treat_democ,
                 t
                 ) %>%
          summarize(
                    mean.comp = mean(
                                     !! quo_var, 
                                     na.rm = TRUE
                                     )
                    )
  
  comp_df$Regime <- ifelse(
                           comp_df$treat_democ == 1,
                           "Democracy",
                           "Non-Democracy"
                           )
  if (type == "smoothed") {
    comp_plot <- ggplot(
                        data.frame(comp_df),
                        aes(
                            x      = t,
                            y      = mean.comp,
                            colour = Regime,
                            fill   = Regime
                            )
                        ) +
                   geom_smooth(size = 1.25) +
                   geom_point(alpha = 0.33) +
                   geom_vline(
                              xintercept = 0,
                              linetype   = "dashed"
                   ) +
                   xlab("Time period") +
                   ylab("Total number of peacekeepers") +
                   theme_bw()
  } else if (type == "spline") {
    spline_df <- data.frame(comp_df)
    spline_df$Spline <- ifelse(
                               spline_df$t < 0,
                               0,
                               spline_df$t
                               )
    mod_spline <- lm(
                     mean.comp ~ 
                                 treat_democ * t + 
                                 treat_democ * Spline, 
                     data = spline_df
                     )
    b <- coef(mod_spline)
    periods <- unique(comp_df$t)
    .spline <- ifelse(
                      periods > 0,
                      periods,
                      0
                      )
    val_dem <- c(b[1] + b[2] + periods * b[3] + .spline * b[4] + periods * b[5] + .spline * b[6])
    val_nondem <- c(b[1] + periods * b[3] + .spline * b[4])
    spline_df$Contribution <- c(
                                val_nondem,
                                val_dem
                                )
    comp_plot <- ggplot(
                        spline_df,
                        aes(
                            x      = t,
                            y      = Contribution,
                            colour = Regime
                          )
                        ) + 
                        geom_vline(
                                   xintercept = 0,
                                   linetype   = "dashed"
                                   ) +
                        geom_point(
                                   data = comp_df,
                                   aes(
                                       x      = t,
                                       y      = mean.comp,
                                       colour = Regime
                                       ),    
                                   alpha = 0.33
                                   ) +
                        geom_line(
                                  aes(linetype = Regime),
                                  size = 1.2
                                  ) +
                        xlab("Time period") +
                        ylab("Average number of peacekeepers") +
                        theme_bw() +
                        theme(
                              legend.key.height = unit(
                                                       1.75,
                                                       "line"
                                                       )
                        )
  } else {
    stop("Argument 'type' must be either 'smoothed' or 'spline'.")
  }
  if (ret_mod == FALSE) {
    return(comp_plot)
  } else {
    return(mod_spline)
  }
}
                        # Function to create a plot with a trend going through
                        # point clouds, either smoothed through a break point
                        # or with a spline

GetSum <- function(
                   data,
                   sum_stat
                   ) {
  if (sum_stat == "length") {
    dat_sum <- apply(
                     data,
                     2,
                     function(x) {
                       sum(!is.na(x))
                     }
                     )
  } else {
    dat_sum <- apply(
                     data,
                     2,
                     sum_stat,
                     na.rm = TRUE
                     ) %>%
                 round(digits = 1)
  }
  return(dat_sum)
}
                        # Function to return summary statistics
                        # from columns in a data frame

DescStats <- function(
                      data,
                      var_names,
                      stat_names,
                      stats
                      ) {
  desc_df <- data.frame(Statistic = var_names)
  for (i in 1 : length(stats)) {
    desc_df[, i + 1] <- GetSum(
                               data,
                               stats[i]
                               )
  }
  colnames(desc_df)[2 : ncol(desc_df)] <- stat_names
  return(desc_df)
}
                        # Return table of descriptive statistics


################
# Read in data #
################

tcc <- read_csv("tcc_level_replication_data.csv") 
missions <- read_csv("mission_level_replication_data.csv")

#############################
# Replication for table and #
# figures in main text      #
#############################

tot_spline <- PlotTrend(
                        tcc,
                        12,
                        Total,
                        "spline"
                        ) +
              xlab("") +
              ylab("Average number of peacekeepers") +
              theme(legend.position = "bottom")

############
# Figure 1 #
############

plot(tot_spline)

##########################
# Mission-level analysis #
##########################

missions$year <- strftime(
                          missions$date,
                          "%Y"
                          )
                        # Get year for each mission-month

missionsfe <- pdata.frame(
                          missions, 
                          index = c(
                                    "Mission_aggregated", 
                                    "date"
                                    )
                          )
                        # Create a mission-month panel data frame

prop_demfe <- feols(
                    prop_dem ~ 
                               post +
                               purpose +
                               lag_mission_deaths +
                               lag_goveff +
                               lag_polstab +
                               lag_ym_popgrwth_perc +
                               log(lag_militaryexp) +
                               New_Total +
                               log(lag_tot + 1) | 
                               Mission_aggregated, 
                    vcov     = "iid",
                    data     = missionsfe, 
                    panel.id = ~ Mission_aggregated
                    )
                        # OLS regression of coalition makeup on
                        # key variables
cont_totfe <- fenegbin(
                       num_tot  ~ 
                                  post +
                                  purpose +
                                  lag_mission_deaths +
                                  lag_goveff +
                                  lag_polstab +
                                  lag_ym_popgrwth_perc +
                                  log(lag_militaryexp) +
                                  New_Total +
                                  log(lag_tot + 1) | 
                                  Mission_aggregated , 
                       vcov     = "iid",
                       data     = missionsfe, 
                       panel.id = ~ Mission_aggregated
                       )
                        # Negative binomial regression of number of
                        # TCCs on key variables
cont_demfe <- fenegbin(
                       num_dem  ~ 
                                  post +
                                  purpose +
                                  lag_mission_deaths +
                                  lag_goveff +
                                  lag_polstab +
                                  lag_ym_popgrwth_perc +
                                  log(lag_militaryexp) +
                                  New_Total +
                                  log(lag_tot + 1) | 
                                  Mission_aggregated , 
                       vcov     = "iid",
                       data     = missionsfe, 
                       panel.id = ~ Mission_aggregated
                       )
                        # Negative binomial regression of number of
                        # democratic TCCs on key variables

###########
# Table 1 #
###########

screenreg(
          list(
               prop_demfe,
               cont_totfe,
               cont_demfe
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          omit.coef          = (".theta"),
          custom.model.names = c("Proportion of democracies",
                                 "Number of contributors",
                                 "Number of democracies"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Civilian protection",
                                 "Casualties",
                                 "Government effectiveness",
                                 "Political stability",
                                 "Population growth",
                                 "Military expenditures",
                                 "New missions",
                                 "Total violence"
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.deviance   = FALSE,
          include.proj.stats = FALSE,
          include.pseudors   = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2",
                                 "Log-likelihood"
                                 )
          )


######################
# TCC-level analysis #
######################

tcc$sp_ind <- paste(
                    tcc$Contributor, 
                    tcc$Mission_aggregated, 
                    tcc$Host, 
                    sep = "_"
                    )
                        # Create a TCC-mission-host-level index

tcc_panel <- pdata.frame(
                         tcc, 
                         index = c(
                                   "sp_ind", 
                                   "date"
                                   )
                         )
                        # Create a panel data frame using the
                        # spatial and temporal indices

total_contfemt <- feols(
                        Total    ~
                                   post +
                                   polity2 +
                                   post:polity2  +
                                   log(lag_militaryexp) +
                                   log(lag_refugeeout) +
                                   lag_casualties +
                                   purpose  +
                                   lag_ym_popgrwth_perc +
                                   New_Total +
                                   log(lag_tot + 1) | 
                                   sp_ind, 
                        vcov     = "iid",
                        data     = tcc_panel,
                        panel.id = ~ sp_ind
                        )
                        # OLS regression of total
                        # contribution on key variables,
                        # using 21-point Polity scale
total_binfemt <- feols(
                       Total    ~
                                  post +
                                  treat_democ +
                                  post:treat_democ +
                                  log(lag_militaryexp) +
                                  log(lag_refugeeout) +
                                  lag_casualties +
                                  purpose  +
                                  lag_ym_popgrwth_perc +
                                  New_Total +
                                  log(lag_tot + 1) | 
                                  sp_ind, 
                       vcov     = "iid",
                       data     = tcc_panel,
                       panel.id = ~ sp_ind
                       )
                        # OLS regression of total
                        # contribution on key variables,
                        # using a binary measure of democracy
smooth_total_contfemt <- feols(
                               Smooth_Total ~
                                              post +
                                              polity2 +
                                              post:polity2 +
                                              log(lag_militaryexp) +
                                              log(lag_refugeeout) +
                                              lag_casualties +
                                              purpose  +
                                              lag_ym_popgrwth_perc +
                                              New_Total +
                                              log(lag_tot + 1) | 
                                              sp_ind, 
                               vcov         = "iid",
                               data         = tcc_panel,
                               panel.id     = ~ sp_ind
                               )
                        # OLS regression of smoothed
                        # contribution on key variables,
                        # using 21-point Polity scale
smooth_total_binfemt <- feols(
                              Smooth_Total ~
                                             post +
                                             treat_democ +
                                             post:treat_democ  +
                                             log(lag_militaryexp) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose  +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) | 
                                             sp_ind, 
                              vcov         = "iid",
                              data         = tcc_panel,
                              panel.id     = ~ sp_ind
                              )
                        # OLS regression of smoothed
                        # contribution on key variables,
                        # using a binary measure of democracy

###########
# Table 2 #
###########

screenreg(
          list(
               total_contfemt,
               total_binfemt,
               smooth_total_contfemt,
               smooth_total_binfemt
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Civilian protection",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.deviance   = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#################################
# Calculate substantive effects #
#################################

plot_polity <- plot_cme(
                        smooth_total_contfemt, 
                        variables = "post", 
                        condition = "polity2"
                        ) +
                 geom_hline(
                            yintercept = 0, 
                            linetype   = "dashed"
                            ) + 
                 xlab("Polity score") + 
                 ylab("Marginal effect of post-election on peacekeeper contribution \n") +
                 theme_bw(base_size = 14) 
                        # Get substantive effects for 
                        # continuous measure of democracy
plot_democracy <- plot_cme(
                           smooth_total_binfemt, 
                           variables = "post", 
                           condition = "treat_democ", 
                           draw      = TRUE
                           ) +
                    geom_hline(
                               yintercept = 0, 
                               linetype   = "dashed"
                               ) + 
                    xlab("Regime type") +
                    ylab("") +
                    scale_x_discrete(
                                     breaks = c(
                                                0,
                                                1
                                                ), 
                                     labels = c(
                                                "Non-democracy",
                                                "Democracy"
                                                )
                                     ) +
                    theme_bw(base_size = 14)
                        # Get substantive effects for 
                        # binary measure of democracy

q <- ggplot_build(plot_polity)
q$data[[1]]$fill <- "blue"
q$data[[1]]$size <- 0.1
q$data[[2]]$colour <- "blue"
q$data[[2]]$linewidth <- 1.25
polity_plot_new <- ggplot_gtable(q)

t <- ggplot_build(plot_democracy)
t$data[[1]]$colour <- "blue"
t$data[[1]]$size <- 1.25
t$data[[1]]$linewidth <- 1.25
democracy_plot_new <- ggplot_gtable(t)
                        # Fix aesthetics for both plots

############
# Figure 2 #
############

grid.arrange(
             polity_plot_new,
             democracy_plot_new,
             ncol = 2
             )

##############################
# Replication for table and  #
# figures in online appendix #
##############################

missions_df <- missions %>% 
                 mutate(
                        loglagmil = log(lag_militaryexp), 
                        totdeath  = log(lag_tot + 1), 
                        loggdp    = log(gdppercapita)
                        ) %>%
                   select(
                          prop_dem,
                          num_tot,
                          num_nd,
                          num_dem,
                          post,
                          purpose,
                          lag_mission_deaths,
                          lag_goveff,
                          lag_polstab,
                          lag_ym_popgrwth_perc,
                          loglagmil,
                          loggdp,
                          integrated_missions,
                          New_Total,
                          totdeath
                          )

tcc_df <- tcc %>% 
            mutate(
                   logdistance = log(distance),
                   logmil      = log(lag_militaryexp),
                   loggdp      = log(gdppercapita),
                   logrefugee  = log(lag_refugeeout),
                   totdeath    = log(lag_tot + 1)
                   ) %>%
              select(
                     Total,
                     Observers,
                     Troops,
                     Civilian_Police,
                     post,
                     polity2,
                     treat_democ,
                     logdistance,
                     logmil,
                     loggdp,
                     integrated_missions,
                     logrefugee,
                     lag_ym_popgrwth_perc,
                     lag_casualties,
                     purpose,
                     Contributor_EU,
                     Contributor_AU,
                     New_Total,
                     totdeath,
                     six_months,
                     one_year
                     )
                        # Get the appropriate variables in each
                        # data set

####################################
# Calculate descriptive statistics #
####################################

miss_vars <- c(
               "Proportion of democracies",
               "Total number of TCCs",
               "Non-democratic TCCs",
               "Democratic TCCs",
               "Post-election",
               "Civilian protection",
               "Casualties",
               "Government effectiveness",
               "Political stability",
               "Pop growth",
               "Military expenditures",
               "GDP per capita",
               "Integrated missions",
               "New missions",
               "Total violence"
               )

tcc_vars <- c(
              "Total peacekeepers",
              "Observers",
              "Troops",
              "Police",
              "Post-election",
              "Polity score",
              "Democracy",
              "Distance",
              "Military spending",
              "GDP per capita",
              "Integrated missions",
              "Refugees",
              "Population growth",
              "Casualties",
              "Civilian protection",
              "EU member",
              "AU member",
              "New missions",
              "Total violence",
              "Six-months to TCC election",
              "One-year to TCC election"
              )

desc_stats <- c(
                "length",
                "mean",
                "sd",
                "min",
                "max"
                )

desc_names <- c(
                "Number of observations",
                "Mean",
                "Standard deviation",
                "Minimum",
                "Maximum"
                )

miss_stats <- DescStats(
                        data       = missions_df,
                        var_names  = miss_vars,
                        stat_names = desc_names,
                        stats      = desc_stats
                        )

tcc_stats <- DescStats(
                       data       = tcc_df,
                       var_names  = tcc_vars,
                       stat_names = desc_names,
                       stats      = desc_stats
                       )

##################
# Table A1 (Top) #
##################

print(miss_stats)

##################
# Table A1 (Bottom) #
##################

print(tcc_stats)

####################################
# Check parallel trends assumption #
####################################

comp_df <- tcc %>% 
            filter(t >= -12 & t <= 12 & !is.na(treat_democ)) %>% 
              group_by(
                       treat_democ,
                       t
                       ) %>% 
                summarize(
                          mean.comp = mean(
                                           Total, 
                                           na.rm = TRUE
                                           )
                          )
                        # Get average contributions across
                        # regimes at different time points

pre <- comp_df %>%
         filter(t <= 0)
post <- comp_df %>%
         filter(t >= 0)

lm_pre <- lm(
             mean.comp ~ t * treat_democ, 
             data = pre
             )

lm_post <- lm(
              mean.comp ~ t * treat_democ,
              data = post
              )

############
# Table A2 #
############

screenreg(
          list(
               lm_pre,
               lm_post
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c("Pre-election",
                                 "Post-election"
                                 ),
          custom.coef.names  = c(
                                 "Constant",
                                 "Time",
                                 "Democracy",
                                 "Democracy x Time"
                                 ),
          reorder.coef       = c(
                                 2 : 4,
                                 1
                                 ),
          include.rsq        = FALSE,
          custom.gof.names   = c(
                                 "Adjusted R^2",
                                 "Number of Observations"
                                 ),
          reorder.gof        = c(
                                 2,
                                 1
                                 )
          )

######################
# Run minimal models #
######################

minimal_contfem <- feols(
                         Total ~
                                 post +
                                 polity2 +
                                 post:polity2 | 
                                 sp_ind, 
                         vcov = "iid",
                         data = tcc_panel,
                         panel.id = ~ sp_ind
                         )

minimal_binfem <- feols(
                        Total ~
                                post +
                                treat_democ +
                                post:treat_democ | 
                                sp_ind, 
                        vcov = "iid",
                        data = tcc_panel,
                        panel.id = ~ sp_ind
                        )

smooth_minimal_contfem <- feols(
                                Smooth_Total ~
                                        post +
                                        polity2 +
                                        post:polity2 | 
                                        sp_ind, 
                                vcov = "iid",
                                data = tcc_panel,
                                panel.id = ~ sp_ind
                                )

smooth_minimal_binfem <- feols(
                               Smooth_Total ~
                                       post +
                                       treat_democ +
                                       post:treat_democ | 
                                       sp_ind, 
                               vcov = "iid",
                               data = tcc_panel,
                               panel.id = ~ sp_ind
                               )

############
# Table A3 #
############

screenreg(
          list(
               minimal_contfem,
               minimal_binfem,
               smooth_minimal_contfem,
               smooth_minimal_binfem
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Polity x Time",
                                 "Democracy",
                                 "Democracy x Time"
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#########################
# Contribution dynamics #
#########################


cinc <- read_csv("NMC_60.csv") %>% 
  select(
         stateabb, 
         year, 
         milex, 
         tpop
         ) %>% 
    filter(year > 1988) %>% 
      mutate(soldier_cost = milex/tpop) %>% 
        select(
               -milex, 
               -tpop
               ) %>%
          group_by(stateabb) %>% 
            mutate(
                   lag_soldier_cost = dplyr::lag(
                                                 soldier_cost, 
                                                 order_by = year
                                                 )
                   )
                        # Bring in data on material capabiltiies

tcc$Contributor_ISO[tcc$Contributor_ISO =="SRB"] <- "YUG"
tcc$Contributor_ISO[tcc$Contributor_ISO =="SCG"] <- "YUG"
tcc$Contributor_ISO[tcc$Contributor_ISO =="CIV"] <- "CDI"
                        # Adjust some abbreviations to make them consistent

gdpdef <- read_csv("GDPDEF.csv")
gdpdef$year<- strftime(gdpdef$DATE,"%Y")
gdpdef <- gdpdef %>% 
            group_by(year) %>% 
              summarize(meandef = mean(GDPDEF))
                        # Bring in GDP data

tcc_soldier <- merge(
                     tcc,
                     cinc,
                     by.x  = c(
                               "Contributor_ISO",
                               "year"
                               ),
                     by.y  = c(
                               "stateabb",
                               "year"
                               ),
                     all.x = TRUE,
                     all.y = FALSE
                   ) %>%
                 merge(
                       gdpdef,
                       by    = "year",
                       all.x = TRUE,
                       all.y =FALSE
                       ) %>%
                   mutate(
                          realgdp    = gdpcurrent * (100 / meandef),
                          logrealgdp = log(realgdp + 1),
                          sp_ind     = paste(
                                             Contributor, 
                                             Mission_aggregated, 
                                             Host, 
                                             sep = "_"
                                             )
                          )

tcc_1_3 <- tcc_soldier %>% 
             filter(t < 4) %>% 
               mutate(
                      one_three = ifelse(
                                         t >= 1 & t < 4, 
                                         1, 
                                         0
                                         ),
                      idx       = paste(
                                        Contributor,
                                        Mission_aggregated,
                                        Host,
                                        date
                                        ),
                      sp_ind    = paste(
                                        Contributor, 
                                        Mission_aggregated, 
                                        Host, 
                                        sep = "_"
                                        )
                      ) %>%
                 pdata.frame(
                             index = c(
                                       "sp_ind",
                                       "date"
                                       )
                             )
                        # Create subset of the data to compare contributions
                        # in the first three months after election to 
                        # pre-election contributions

tcc_4_6 <- tcc_soldier %>% 
             filter(
                    !(t %in% c(1 : 3)),
                    t < 7
                    ) %>% 
               mutate(
                      four_six = ifelse(
                                        t > 3 & t < 7, 
                                        1, 
                                        0
                                        ),
                      idx      = paste(
                                       Contributor,
                                       Mission_aggregated,
                                       Host,
                                       date
                                       ),
                      sp_ind   = paste(
                                       Contributor, 
                                       Mission_aggregated, 
                                       Host, 
                                       sep = "_"
                                       )
                      ) %>%
                 pdata.frame(
                             index = c(
                                       "sp_ind",
                                       "date"
                                       )
                             )
                        # Create subset of the data to compare contributions
                        # in the second three months after election to 
                        # pre-election contributions


soon_contfemt <- feols(
                       Total    ~
                                  one_three +
                                  polity2 +
                                  one_three:polity2  +
                                  log(lag_militaryexp) +
                                  log(lag_soldier_cost) +
                                  log(lag_refugeeout) +
                                  lag_casualties +
                                  purpose  +
                                  lag_ym_popgrwth_perc +
                                  New_Total +
                                  log(lag_tot+1) | 
                                  sp_ind, 
                       vcov     = "iid",
                       data     = tcc_1_3,
                       panel.id = ~ sp_ind
                       )

soon_binfemt <- feols(
                      Total    ~
                                  one_three +
                                  treat_democ +
                                  one_three:treat_democ  +
                                  log(lag_militaryexp) +
                                  log(lag_soldier_cost) +
                                  log(lag_refugeeout) +
                                  lag_casualties +
                                  purpose  +
                                  lag_ym_popgrwth_perc +
                                  New_Total +
                                  log(lag_tot+1) | 
                                  sp_ind, 
                       vcov     = "iid",
                       data     = tcc_1_3,
                       panel.id = ~ sp_ind
                       )

smooth_soon_contfemt <- feols(
                              Smooth_Total ~
                                             one_three +
                                             polity2 +
                                             one_three:polity2  +
                                             log(lag_militaryexp) +
                                             log(lag_soldier_cost) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose  +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) | 
                                             sp_ind, 
                              vcov         = "iid",
                              data         = tcc_1_3,
                              panel.id     = ~ sp_ind
                              )

smooth_soon_binfemt <- feols(
                             Smooth_Total ~
                                            one_three +
                                            treat_democ +
                                            one_three:treat_democ  +
                                            log(lag_militaryexp) +
                                            log(lag_soldier_cost) +
                                            log(lag_refugeeout) +
                                            lag_casualties +
                                            purpose  +
                                            lag_ym_popgrwth_perc +
                                            New_Total +
                                            log(lag_tot+1) | 
                                            sp_ind, 
                             vcov         = "iid",
                             data         = tcc_1_3,
                             panel.id     = ~ sp_ind
                             )

late_contfemt <- feols(
                       Total    ~
                                  four_six +
                                  polity2 +
                                  four_six:polity2  +
                                  log(lag_militaryexp) +
                                  log(lag_soldier_cost) +
                                  log(lag_refugeeout) +
                                  lag_casualties +
                                  purpose  +
                                  lag_ym_popgrwth_perc +
                                  New_Total +
                                  log(lag_tot+1) | 
                                  sp_ind, 
                       vcov     = "iid",
                       data     = tcc_4_6,
                       panel.id = ~ sp_ind
                       )

late_binfemt <- feols(
                      Total    ~
                                  four_six +
                                  treat_democ +
                                  four_six:treat_democ  +
                                  log(lag_militaryexp) +
                                  log(lag_soldier_cost) +
                                  log(lag_refugeeout) +
                                  lag_casualties +
                                  purpose  +
                                  lag_ym_popgrwth_perc +
                                  New_Total +
                                  log(lag_tot+1) | 
                                  sp_ind, 
                       vcov     = "iid",
                       data     = tcc_4_6,
                       panel.id = ~ sp_ind
                       )

smooth_late_contfemt <- feols(
                              Smooth_Total ~
                                             four_six +
                                             polity2 +
                                             four_six:polity2  +
                                             log(lag_militaryexp) +
                                             log(lag_soldier_cost) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose  +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) | 
                                             sp_ind, 
                              vcov         = "iid",
                              data         = tcc_4_6,
                              panel.id     = ~ sp_ind
                              )

smooth_late_binfemt <- feols(
                             Smooth_Total ~
                                            four_six +
                                            treat_democ +
                                            four_six:treat_democ  +
                                            log(lag_militaryexp) +
                                            log(lag_soldier_cost) +
                                            log(lag_refugeeout) +
                                            lag_casualties +
                                            purpose  +
                                            lag_ym_popgrwth_perc +
                                            New_Total +
                                            log(lag_tot+1) | 
                                            sp_ind, 
                             vcov         = "iid",
                             data         = tcc_4_6,
                             panel.id     = ~ sp_ind
                             )

############
# Table A4 #
############

screenreg(
          list(
               soon_contfemt,
               soon_binfemt,
               smooth_soon_contfemt,
               smooth_soon_binfemt
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election (1-3 months)",
                                 "Polity score",
                                 "Military expenditures",
                                 "Cost of soldier",
                                 "Refugees",
                                 "Casualties",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x post-election (1-3 months)",
                                 "Democracy",
                                 "Democracy x post-election (1-3 months)"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

############
# Table A5 #
############

screenreg(
          list(
               late_contfemt,
               late_binfemt,
               smooth_late_contfemt,
               smooth_late_binfemt
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election (4-6 months)",
                                 "Polity score",
                                 "Military expenditures",
                                 "Cost of soldier",
                                 "Refugees",
                                 "Casualties",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x post-election (4-6 months)",
                                 "Democracy",
                                 "Democracy x post-election (4-6 months)"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

##################################
# Disaggregate peacekeeper types #
##################################

troopfe1 <- feols(
                  Troops   ~ 
                             post +
                             polity2 +
                             post:polity2 + 
                             log(lag_militaryexp) +
                             log(lag_refugeeout) +
                             lag_casualties +purpose  +
                             lag_ym_popgrwth_perc +
                             New_Total +
                             log(lag_tot+1) | 
                             sp_ind, 
                  vcov     = "iid",
                  data     = tcc_panel,
                  panel.id = ~ sp_ind
                  )

troopfe2 <- feols(
                  Troops    ~ 
                              post +
                              treat_democ +
                              post:treat_democ + 
                              log(lag_militaryexp) +
                              log(lag_refugeeout) +
                              lag_casualties +purpose  +
                              lag_ym_popgrwth_perc +
                              New_Total +
                              log(lag_tot+1) | 
                              sp_ind, 
                  vcov     = "iid",
                  data     = tcc_panel,
                  panel.id = ~ sp_ind
                  )

troopfe3 <- feols(
                  Smooth_Troops ~ 
                                     post +
                                     polity2 +
                                     post:polity2 + 
                                     log(lag_militaryexp) +
                                     log(lag_refugeeout) +
                                     lag_casualties +purpose  +
                                     lag_ym_popgrwth_perc +
                                     New_Total +
                                     log(lag_tot+1) | 
                                     sp_ind, 
                  vcov             = "iid",
                  data             = tcc_panel,
                  panel.id         = ~ sp_ind
                  )

troopfe4 <- feols(
                  Smooth_Troops ~ 
                                     post +
                                     treat_democ +
                                     post:treat_democ + 
                                     log(lag_militaryexp) +
                                     log(lag_refugeeout) +
                                     lag_casualties +purpose  +
                                     lag_ym_popgrwth_perc +
                                     New_Total +
                                     log(lag_tot+1) | 
                                     sp_ind, 
                  vcov             = "iid",
                  data             = tcc_panel,
                  panel.id         = ~ sp_ind
                  )


policefe1 <- feols(
                   Civilian_Police ~ 
                                      post +
                                      polity2 +
                                      post:polity2 + 
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +purpose  +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) | 
                                      sp_ind, 
                   vcov             = "iid",
                   data             = tcc_panel,
                   panel.id         = ~ sp_ind
                   )

policefe2 <- feols(
                   Civilian_Police ~ 
                                      post +
                                      treat_democ +
                                      post:treat_democ + 
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +purpose  +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) | 
                                      sp_ind, 
                   vcov             = "iid",
                   data             = tcc_panel,
                   panel.id         = ~ sp_ind
                   )

policefe3 <- feols(
                   Smooth_Police ~ 
                                      post +
                                      polity2 +
                                      post:polity2 + 
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +purpose  +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) | 
                                      sp_ind, 
                   vcov             = "iid",
                   data             = tcc_panel,
                   panel.id         = ~ sp_ind
                   )

policefe4 <- feols(
                   Smooth_Police ~ 
                                      post +
                                      treat_democ +
                                      post:treat_democ + 
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +purpose  +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) | 
                                      sp_ind, 
                   vcov             = "iid",
                   data             = tcc_panel,
                   panel.id         = ~ sp_ind
                   )


observerfe1 <- feols(
                     Observers ~ 
                                        post +
                                        polity2 +
                                        post:polity2 + 
                                        log(lag_militaryexp) +
                                        log(lag_refugeeout) +
                                        lag_casualties +purpose  +
                                        lag_ym_popgrwth_perc +
                                        New_Total +
                                        log(lag_tot+1) | 
                                        sp_ind, 
                     vcov             = "iid",
                     data             = tcc_panel,
                     panel.id         = ~ sp_ind
                     )

observerfe2 <- feols(
                     Observers ~ 
                                        post +
                                        treat_democ +
                                        post:treat_democ + 
                                        log(lag_militaryexp) +
                                        log(lag_refugeeout) +
                                        lag_casualties +purpose  +
                                        lag_ym_popgrwth_perc +
                                        New_Total +
                                        log(lag_tot+1) | 
                                        sp_ind, 
                     vcov             = "iid",
                     data             = tcc_panel,
                     panel.id         = ~ sp_ind
                     )

observerfe3 <- feols(
                     Smooth_Observers ~ 
                                        post +
                                        polity2 +
                                        post:polity2 + 
                                        log(lag_militaryexp) +
                                        log(lag_refugeeout) +
                                        lag_casualties +purpose  +
                                        lag_ym_popgrwth_perc +
                                        New_Total +
                                        log(lag_tot+1) | 
                                        sp_ind, 
                     vcov             = "iid",
                     data             = tcc_panel,
                     panel.id         = ~ sp_ind
                     )

observerfe4 <- feols(
                     Smooth_Observers ~ 
                                        post +
                                        treat_democ +
                                        post:treat_democ + 
                                        log(lag_militaryexp) +
                                        log(lag_refugeeout) +
                                        lag_casualties +purpose  +
                                        lag_ym_popgrwth_perc +
                                        New_Total +
                                        log(lag_tot+1) | 
                                        sp_ind, 
                     vcov             = "iid",
                     data             = tcc_panel,
                     panel.id         = ~ sp_ind
                     )

############
# Table A6 #
############

screenreg(
          list(
               troopfe1,
               troopfe2,
               troopfe3,
               troopfe4,
               policefe1,
               policefe2,
               policefe3,
               policefe4,
               observerfe1,
               observerfe2,
               observerfe3,
               observerfe4
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of troops (continuous democracy)",
                                 "Count of troops (binary democracy)",
                                 "Count of troops (smoothed, continuous democracy)",
                                 "Count of troops (smoothed, binary democracy)",
                                 "Count of police (continuous democracy)",
                                 "Count of police (binary democracy)",
                                 "Count of police (smoothed, continuous democracy)",
                                 "Count of police (smoothed, binary democracy)",
                                 "Count of observers (continuous democracy)",
                                 "Count of observers (binary democracy)",
                                 "Count of observers (smoothed, continuous democracy)",
                                 "Count of observers (smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Civilian protection",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#################
# TCC elections #
#################


num_contfe <- feols(
                    Total    ~ 
                               post +
                               polity2 +
                               post:polity2 +
                               log(lag_militaryexp) +
                               log(lag_refugeeout) +
                               lag_casualties +
                               purpose  +
                               lag_ym_popgrwth_perc +
                               New_Total +
                               log(lag_tot + 1) + 
                               six_months | 
                               sp_ind, 
                    vcov     = "iid",
                    data     = tcc_panel,
                    panel.id = ~ sp_ind
                    )

num_binfe <- feols(
                   Total    ~ 
                              post +
                              treat_democ +
                              post:treat_democ +
                              log(lag_militaryexp) +
                              log(lag_refugeeout) +
                              lag_casualties +
                              purpose  +
                              lag_ym_popgrwth_perc +
                              New_Total +
                              log(lag_tot + 1) + 
                              six_months | 
                              sp_ind, 
                   vcov     = "iid",
                   data     = tcc_panel,
                   panel.id = ~ sp_ind
                   )

num_cont2fe <- feols(
                     Total    ~ 
                                post +
                                polity2 +
                                post:polity2 +
                                log(lag_militaryexp) +
                                log(lag_refugeeout) +
                                lag_casualties +
                                purpose  +
                                lag_ym_popgrwth_perc +
                                New_Total +
                                log(lag_tot + 1) + 
                                one_year | 
                                sp_ind, 
                     vcov     = "iid",
                     data     = tcc_panel,
                     panel.id = ~ sp_ind
                     )

num_bin2fe <- feols(
                    Total    ~ 
                               post +
                               treat_democ +
                               post:treat_democ +
                               log(lag_militaryexp) +
                               log(lag_refugeeout) +
                               lag_casualties +
                               purpose  +
                               lag_ym_popgrwth_perc +
                               New_Total +
                               log(lag_tot + 1) + 
                               one_year | 
                               sp_ind, 
                    vcov     = "iid",
                    data     = tcc_panel,
                    panel.id = ~ sp_ind
                    )


snum_contfe <- feols(
                     Smooth_Total ~ 
                                    post +
                                    polity2 +
                                    post:polity2 +
                                    log(lag_militaryexp) +
                                    log(lag_refugeeout) +
                                    lag_casualties +
                                    purpose  +
                                    lag_ym_popgrwth_perc +
                                    New_Total +
                                    log(lag_tot + 1) + 
                                    six_months | 
                                    sp_ind, 
                     vcov         = "iid",
                     data         = tcc_panel,
                     panel.id     = ~ sp_ind
                     )

snum_binfe <- feols(
                    Smooth_Total ~ 
                                   post +
                                   treat_democ +
                                   post:treat_democ +
                                   log(lag_militaryexp) +
                                   log(lag_refugeeout) +
                                   lag_casualties +
                                   purpose  +
                                   lag_ym_popgrwth_perc +
                                   New_Total +
                                   log(lag_tot + 1) + 
                                   six_months | 
                                   sp_ind, 
                    vcov         = "iid",
                    data         = tcc_panel,
                    panel.id     = ~ sp_ind
                    )

snum_cont2fe <- feols(
                      Smooth_Total ~ 
                                     post +
                                     polity2 +
                                     post:polity2 +
                                     log(lag_militaryexp) +
                                     log(lag_refugeeout) +
                                     lag_casualties +
                                     purpose  +
                                     lag_ym_popgrwth_perc +
                                     New_Total +
                                     log(lag_tot + 1) + 
                                     one_year | 
                                     sp_ind, 
                      vcov         = "iid",
                      data         = tcc_panel,
                      panel.id     = ~ sp_ind
                      )

snum_bin2fe <- feols(
                     Smooth_Total ~ 
                                    post +
                                    treat_democ +
                                    post:treat_democ +
                                    log(lag_militaryexp) +
                                    log(lag_refugeeout) +
                                    lag_casualties +
                                    purpose  +
                                    lag_ym_popgrwth_perc +
                                    New_Total +
                                    log(lag_tot + 1) + 
                                    one_year | 
                                    sp_ind, 
                     vcov         = "iid",
                     data         = tcc_panel,
                     panel.id     = ~ sp_ind
                     )

############
# Table A7 #
############

screenreg(
          list(
               num_contfe,
               num_cont2fe,
               num_binfe,
               num_bin2fe,
               snum_contfe,
               snum_cont2fe,
               snum_binfe,
               snum_bin2fe
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (TCC election within six months, continuous democracy)",
                                 "Count of peacekeepers (TCC election within one year, continuous democracy)",
                                 "Count of peacekeepers (TCC election within six months, binary democracy)",
                                 "Count of peacekeepers (TCC election within one year, binary democracy)",
                                 "Count of peacekeepers (TCC election within six months, smoothed, continuous democracy)",
                                 "Count of peacekeepers (TCC election within one year, smoothed, continuous democracy)",
                                 "Count of peacekeepers (TCC election within six months, smoothed, binary democracy)",
                                 "Count of peacekeepers (TCC election within one year, smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Civilian protection",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Six months to TCC election",
                                 "Polity x post-election",
                                 "One year to TCC election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 11,
                                 13 : 14,
                                 3 : 10,
                                 12
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

########################################
# Real GDP as an indicator of economic #
# performance and cost of training     #
########################################

tcc_cost <- pdata.frame(
                        tcc_soldier, 
                        index = c(
                                  "sp_ind", 
                                  "date"
                                  )
                        )

main_costsoldier1 <- feols(
                           Total    ~ 
                                      post +
                                      polity2 +
                                      post:polity2  +
                                      logrealgdp +
                                      log(lag_militaryexp) +
                                      log(lag_soldier_cost) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      purpose  +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot + 1) | 
                                      sp_ind, 
                           vcov     = "iid",
                           data     = tcc_cost,
                           panel.id = ~ sp_ind
                           )

main_costsoldier2 <- feols(
                           Total    ~ 
                                      post +
                                      treat_democ +
                                      post:treat_democ  +
                                      logrealgdp +
                                      log(lag_militaryexp) +
                                      log(lag_soldier_cost) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      purpose  +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot + 1) | 
                                      sp_ind, 
                           vcov     = "iid",
                           data     = tcc_cost,
                           panel.id = ~ sp_ind
                           )

main_costsoldier3 <- feols(
                           Smooth_Total ~ 
                                          post +
                                          polity2 +
                                          post:polity2  +
                                          logrealgdp +
                                          log(lag_militaryexp) +
                                          log(lag_soldier_cost) +
                                          log(lag_refugeeout) +
                                          lag_casualties +
                                          purpose  +
                                          lag_ym_popgrwth_perc +
                                          New_Total +
                                          log(lag_tot + 1) | 
                                          sp_ind, 
                           vcov         = "iid",
                           data         = tcc_cost,
                           panel.id     = ~ sp_ind
                           )

main_costsoldier4 <- feols(
                           Smooth_Total ~ 
                                          post +
                                          treat_democ +
                                          post:treat_democ  +
                                          logrealgdp +
                                          log(lag_militaryexp) +
                                          log(lag_soldier_cost) +
                                          log(lag_refugeeout) +
                                          lag_casualties +
                                          purpose  +
                                          lag_ym_popgrwth_perc +
                                          New_Total +
                                          log(lag_tot + 1) | 
                                          sp_ind, 
                           vcov         = "iid",
                           data         = tcc_cost,
                           panel.id     = ~ sp_ind
                           )

############
# Table A8 #
############

screenreg(
          list(
               main_costsoldier1,
               main_costsoldier2,
               main_costsoldier3,
               main_costsoldier4
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Real GDP",
                                 "Military expenditures",
                                 "Cost of soldier",
                                 "Refugees",
                                 "Casualties",
                                 "Civilian protection",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 12 : 14,
                                 3 : 11
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#######################
# Token contributions #
#######################

token_TCC <- tcc %>% 
               filter(Total >= 40) %>%
                 mutate(
                        sp_ind = paste(
                                       Contributor,
                                       Mission_aggregated,
                                       Host,
                                       sep = "_"
                                       )
                        )
                        # Remove cases in which TCCs contribute fewer
                        # than forty peacekeepers, and create an
                        # index variable

token_tcc <- pdata.frame(
                         token_TCC, 
                         index = c(
                                   "sp_ind", 
                                   "date"
                                   )
                         )

token_contfemt <- feols(
                        Total    ~
                                   post +
                                   polity2 +
                                   post:polity2  +
                                   log(lag_militaryexp) +
                                   log(lag_refugeeout) +
                                   lag_casualties +
                                   purpose  +
                                   lag_ym_popgrwth_perc +
                                   New_Total +
                                   log(lag_tot+1) | 
                                   sp_ind, 
                        vcov     = "iid",
                        data     = token_tcc,
                        panel.id = ~ sp_ind
                        )
token_binfemt <- feols(
                       Total     ~
                                   post +
                                   treat_democ +
                                   post:treat_democ  +
                                   log(lag_militaryexp) +
                                   log(lag_refugeeout) +
                                   lag_casualties +
                                   purpose  +
                                   lag_ym_popgrwth_perc +
                                   New_Total +
                                   log(lag_tot+1) | 
                                   sp_ind, 
                        vcov     = "iid",
                        data     = token_tcc,
                        panel.id = ~ sp_ind
                        )
smooth_token_contfemt <- feols(
                               Smooth_Total ~
                                              post +
                                              polity2 +
                                              post:polity2  +
                                              log(lag_militaryexp) +
                                              log(lag_refugeeout) +
                                              lag_casualties +
                                              purpose  +
                                              lag_ym_popgrwth_perc +
                                              New_Total +
                                              log(lag_tot+1) | 
                                              sp_ind, 
                               vcov         = "iid",
                               data         = token_tcc,
                               panel.id     = ~ sp_ind
                               )
smooth_token_binfemt <- feols(
                              Smooth_Total ~
                                             post +
                                             treat_democ +
                                             post:treat_democ  +
                                             log(lag_militaryexp) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) | 
                                             sp_ind, 
                              vcov         = "iid",
                              data         = token_tcc,
                              panel.id     = ~ sp_ind
                              )

############
# Table A9 #
############

#######################
# NOT CONSISTENT 
# WITH APPENDIX
##########################

screenreg(
          list(
               token_contfemt,
               token_binfemt,
               smooth_token_contfemt,
               smooth_token_binfemt
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Civilian protection",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

######################################
# Alternative approach to withdrawal #
######################################

num_contafe <- feols(
                     Total    ~ 
                                lag_casualties+
                                polity2 +
                                lag_casualties : polity2  +
                                log(lag_militaryexp) +
                                log(lag_refugeeout) +
                                purpose  +
                                lag_ym_popgrwth_perc +
                                New_Total +
                                log(lag_tot + 1) | 
                                sp_ind, 
                     vcov     = "iid",
                     data     = tcc_panel,
                     panel.id = ~ sp_ind
                     )
num_binafe <- feols(
                    Total    ~ 
                               lag_casualties+
                               treat_democ +
                               lag_casualties : treat_democ  +
                               log(lag_militaryexp) +
                               log(lag_refugeeout) +
                               purpose  +
                               lag_ym_popgrwth_perc +
                               New_Total +
                               log(lag_tot + 1)| sp_ind , 
                    vcov     = "iid",
                    data     = tcc_panel,
                    panel.id = ~ sp_ind
                    )
num_conta2fe <- feols(
                      Smooth_Total ~ 
                                     lag_casualties+
                                     polity2 +
                                     lag_casualties : polity2  +
                                     log(lag_militaryexp) +
                                     log(lag_refugeeout) +
                                     purpose  +
                                     lag_ym_popgrwth_perc +
                                     New_Total +
                                     log(lag_tot+ 1)| sp_ind, 
                    vcov           = "iid",
                    data           = tcc_panel,
                    panel.id       = ~ sp_ind
                      )
num_bina2fe <- feols(
                     Smooth_Total ~ 
                                    lag_casualties+
                                    treat_democ +
                                    lag_casualties : treat_democ  +
                                    log(lag_militaryexp) +
                                    log(lag_refugeeout) +
                                    purpose  +
                                    lag_ym_popgrwth_perc +
                                    New_Total +
                                    log(lag_tot+1)| sp_ind, 
                    vcov          = "iid",
                    data          = tcc_panel,
                    panel.id      = ~ sp_ind
                     )

#############
# Table A10 #
#############

screenreg(
          list(
               num_contafe,
               num_binafe,
               num_conta2fe,
               num_bina2fe
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (continuous democracy)",
                                 "Count of peacekeepers (binary democracy)",
                                 "Smoothed peacekeepers (continuous democracy)",
                                 "Smoothed peacekeepers (binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Casualties",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Civilian protection",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Polity x casualties",
                                 "Democracy",
                                 "Democracy x casualties"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 9 : 11,
                                 3 : 8
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

####################################
# Control for authorized personnel #
####################################

JPR_authorized_missions = c(
                            "BINUB",
                            "BONUCA",
                            "MINUCI",
                            "MINURCA",
                            "MINURCAT",
                            "MINURSO",
                            "MONUA",
                            "MONUC",
                            "ONUB",
                            "ONUMOZ",
                            "UNAMID",
                            "UNAMIR",
                            "UNAMSIL",
                            "UNAVEM",
                            "UNISFA",
                            "UNMA",
                            "UNMIL",
                            "UNMIS",
                            "UNMISS",
                            "UNOA",
                            "UNOCI",
                            "UNOMIL",
                            "UNOMSIL",
                            "UNOMUR",
                            "UNOSOM",
                            "UNOSOM II"
                            )

nested_authorized_data <- tcc %>% 
                            filter(Mission %in% JPR_authorized_missions) %>%
                              mutate(
                                     sp_ind = paste(Contributor, 
                                                    Mission_aggregated, 
                                                    Host, 
                                                    sep="_"
                                                    )
                                     ) %>%
                                pdata.frame(
                                            index = c(
                                                      "sp_ind",
                                                      "date"
                                                      )
                                            )
                        # Create a panel data set for those missions for
                        # which we have authorization data


auth_data <- nested_authorized_data %>%
               mutate(
                      logdistance = log(distance),
                      logmil      = log(lag_militaryexp),
                      loggdp      = log(gdppercapita),
                      logrefugee  = log(lag_refugeeout),
                      totdeath    = log(lag_tot + 1)
                      ) %>%
                 select(
                        "Total", 
                        "Observers", 
                        "Troops", 
                        "Civilian_Police",
                        "post",
                        "polity2",
                        "treat_democ",
                        "logdistance",
                        "logmil", 
                        "loggdp",
                        "integrated_missions",
                        "logrefugee",
                        "lag_ym_popgrwth_perc",
                        "lag_casualties",
                        "purpose", 
                        "Contributor_EU", 
                        "Contributor_AU", 
                        "New_Total", 
                        "totdeath", 
                        "six_months", 
                        "one_year"
                        ) 

auth_vars <- c(
               "Total peacekeepers",
               "Observers",
               "Troops",
               "Police",
               "Post-election",
               "Polity score",
               "Democracy",
               "Distance",
               "Military spending",
               "GDP per capita",
               "Integrated missions",
               "Refugees",
               "Population growth",
               "Casualties",
               "Civilian protection",
               "EU member",
               "AU member",
               "New missions",
               "Total violence",
               "Six-months to TCC election",
               "One-year to TCC election"
               )

auth_stats <- c(
                "length",
                "mean",
                "sd",
                "min",
                "max"
                )

auth_names <- c(
                "Number of observations",
                "Mean",
                "Standard deviation",
                "Minimum",
                "Maximum"
                )

auth_df <- DescStats(
                     data       = auth_data,
                     var_names  = auth_vars,
                     stat_names = auth_names,
                     stats      = auth_stats
                     )

Authtotal_cont <- feols(
                        Total    ~
                                   post +
                                   polity2 +
                                   post:polity2 +
                                   officially_authorized |
                                   sp_ind, 
                        vcov     = "iid",
                        data     = nested_authorized_data, 
                        panel.id = ~ sp_ind
                        )
Authtotal_bin <- feols(
                       Total    ~
                                  post +
                                  treat_democ +
                                  post:treat_democ +
                                  officially_authorized |
                                  sp_ind, 
                       vcov     = "iid",
                       data     = nested_authorized_data, 
                       panel.id = ~ sp_ind
                       )
Authsmooth_total_cont <- feols(
                               Smooth_Total ~
                                              post +
                                              polity2 +
                                              post:polity2 +
                                              officially_authorized |
                                              sp_ind, 
                               vcov        = "iid",
                               data        = nested_authorized_data, 
                               panel.id    = ~ sp_ind
                               )
Authsmooth_total_bin <- feols(
                              Smooth_Total ~
                                             post +
                                             treat_democ +
                                             post:treat_democ +
                                             officially_authorized |
                                             sp_ind, 
                             vcov          = "iid",
                             data          = nested_authorized_data, 
                             panel.id      = ~ sp_ind
                             )

Authtotal_cont2 <- feols(
                         Total    ~
                                    post +
                                    polity2 +
                                    post:polity2 |
                                    sp_ind, 
                         vcov     = "iid",
                         data     = nested_authorized_data, 
                         panel.id = ~ sp_ind
                         )
Authtotal_bin2 <- feols(
                        Total     ~
                                    post +
                                    treat_democ +
                                    post:treat_democ |
                                    sp_ind, 
                        vcov     = "iid",
                        data     = nested_authorized_data, 
                        panel.id = ~ sp_ind
                        )
Authsmooth_total_cont2 <- feols(
                                Smooth_Total ~
                                               post +
                                               polity2 +
                                               post:polity2 |
                                               sp_ind, 
                                vcov         = "iid",
                                data         = nested_authorized_data, 
                                panel.id     = ~ sp_ind
                                )
Authsmooth_total_bin2 <- feols(
                               Smooth_Total ~
                                              post +
                                              treat_democ +
                                              post:treat_democ |
                                              sp_ind, 
                               vcov         = "iid",
                               data         = nested_authorized_data, 
                               panel.id     = ~ sp_ind
                               )
                        # Run baseline authorization models

auth_mult_total1a <- feols(
                           Total    ~ 
                                      post +
                                      polity2 +
                                      post:polity2 +
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) +
                                      officially_authorized |
                                      sp_ind, 
                           vcov     = "iid",
                           data     = nested_authorized_data, 
                           panel.id = ~ sp_ind
                           )
auth_mult_total2a <- feols(
                           Total    ~ 
                                      post +
                                      treat_democ +
                                      post:treat_democ +
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) +
                                      officially_authorized |
                                      sp_ind, 
                           vcov     = "iid",
                           data     = nested_authorized_data, 
                           panel.id = ~ sp_ind
                           )
auth_mult_totals1a <- feols(
                            Smooth_Total ~ 
                                           post +
                                           polity2 +
                                           post:polity2 +
                                           log(lag_militaryexp) +
                                           log(lag_refugeeout) +
                                           lag_casualties +
                                           lag_ym_popgrwth_perc +
                                           New_Total +
                                           log(lag_tot+1)+ officially_authorized |
                                           sp_ind, 
                            vcov        = "iid",
                            data        = nested_authorized_data, 
                            panel.id    = ~ sp_ind
                            )
auth_mult_totals2a <- feols(
                            Smooth_Total ~ 
                                           post +
                                           treat_democ +
                                           post:treat_democ +
                                           log(lag_militaryexp) +
                                           log(lag_refugeeout) +
                                           lag_casualties +
                                           lag_ym_popgrwth_perc +
                                           New_Total +
                                           log(lag_tot+1) +
                                           officially_authorized |
                                           sp_ind, 
                            vcov         = "iid",
                            data         = nested_authorized_data, 
                            panel.id     = ~ sp_ind
                            )

auth_mult_total1 <- feols(
                          Total    ~ 
                                     post +
                                     polity2 +
                                     post:polity2 +
                                     log(lag_militaryexp) +
                                     log(lag_refugeeout) +
                                     lag_casualties +
                                     lag_ym_popgrwth_perc +
                                     New_Total +
                                     log(lag_tot + 1) |
                                     sp_ind, 
                          vcov     = "iid",
                          data     = nested_authorized_data, 
                          panel.id = ~ sp_ind
                          )
auth_mult_total2 <- feols(
                          Total     ~ 
                                      post +
                                      treat_democ +
                                      post:treat_democ +
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot + 1) |
                                      sp_ind, 
                          vcov     = "iid",
                          data     = nested_authorized_data, 
                          panel.id = ~ sp_ind
                          )
auth_mult_totals1 <- feols(
                           Smooth_Total ~
                                          post +
                                          polity2 +
                                          post:polity2 +
                                          log(lag_militaryexp) +
                                          log(lag_refugeeout) +
                                          lag_casualties +
                                          lag_ym_popgrwth_perc +
                                          New_Total +
                                          log(lag_tot + 1) |
                                          sp_ind, 
                            vcov        = "iid",
                            data        = nested_authorized_data, 
                            panel.id    = ~ sp_ind
                            )
auth_mult_totals2 <- feols(
                           Smooth_Total ~ 
                                          post +
                                          treat_democ +
                                          post:treat_democ +
                                          log(lag_militaryexp) +
                                          log(lag_refugeeout) +
                                          lag_casualties +
                                          lag_ym_popgrwth_perc +
                                          New_Total +
                                          log(lag_tot + 1) |
                                          sp_ind, 
                            vcov        = "iid",
                            data        = nested_authorized_data, 
                            panel.id    = ~ sp_ind
                            )
                        # Run authorization models with full controls,
                        # but note that the authorization variable
                        # precludes certain independent variables used
                        # elsewhere due to perfect multicollinearity 
                        # (including distance, civilian protection,
                        # and EU and AU contributors)

auth_mult_troop1a <- feols(
                           Troops   ~
                                      post +
                                      polity2 +
                                      post:polity2 +
                                      log(distance) +
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      purpose +
                                      Contributor_EU +
                                      Contributor_AU +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) +
                                      officially_authorized |
                                      sp_ind,
                           vcov     = "iid",
                           data     = nested_authorized_data,
                           panel.id = ~ sp_ind
                             )

auth_mult_troop2a <- feols(
                           Troops     ~
                                        post +
                                        treat_democ +
                                        post:treat_democ +
                                        log(distance) +
                                        log(lag_militaryexp) +
                                        log(lag_refugeeout) +
                                        lag_casualties +
                                        purpose +
                                        Contributor_EU +
                                        Contributor_AU +
                                        lag_ym_popgrwth_perc +
                                        New_Total +
                                        log(lag_tot+1) +
                                        officially_authorized |
                                        sp_ind, 
                            vcov     = "iid",
                            data     = nested_authorized_data, 
                            panel.id = ~ sp_ind
                            )

auth_mult_troops1a <- feols(
                            Smooth_Troops ~
                                            post +
                                            polity2 +
                                            post:polity2 +
                                            log(distance) +
                                            log(lag_militaryexp) +
                                            log(lag_refugeeout) +
                                            lag_casualties +
                                            purpose +
                                            Contributor_EU +
                                            Contributor_AU +
                                            lag_ym_popgrwth_perc +
                                            New_Total +
                                            log(lag_tot+1)+ officially_authorized |
                                            sp_ind, 
                             vcov         = "iid",
                             data         = nested_authorized_data, 
                             panel.id     = ~ sp_ind
                             )

auth_mult_troops2a <- feols(
                            Smooth_Troops ~
                                            post +
                                            treat_democ +
                                            post:treat_democ +
                                            log(distance) +
                                            log(lag_militaryexp) +
                                            log(lag_refugeeout) +
                                            lag_casualties +
                                            purpose +
                                            Contributor_EU +
                                            Contributor_AU +
                                            lag_ym_popgrwth_perc +
                                            New_Total +
                                            log(lag_tot+1) +
                                            officially_authorized |
                                            sp_ind, 
                             vcov         = "iid",
                             data         = nested_authorized_data, 
                             panel.id     = ~ sp_ind
                             )

auth_mult_troop1 <- feols(
                          Troops    ~
                                      post +
                                      polity2 +
                                      post:polity2 +
                                      log(distance) +
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      purpose +
                                      Contributor_EU +
                                      Contributor_AU +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) |
                                      sp_ind, 
                           vcov     = "iid",
                           data     = nested_authorized_data, 
                           panel.id = ~ sp_ind
                           )

auth_mult_troop2 <- feols(
                          Troops    ~
                                      post +
                                      treat_democ +
                                      post:treat_democ +
                                      log(distance) +
                                      log(lag_militaryexp) +
                                      log(lag_refugeeout) +
                                      lag_casualties +
                                      purpose +
                                      Contributor_EU +
                                      Contributor_AU +
                                      lag_ym_popgrwth_perc +
                                      New_Total +
                                      log(lag_tot+1) |
                                      sp_ind, 
                           vcov     = "iid",
                           data     = nested_authorized_data, 
                           panel.id = ~ sp_ind
                           )

auth_mult_troops1 <- feols(
                           Smooth_Troops ~
                                           post +
                                           polity2 +
                                           post:polity2 +
                                           log(distance) +
                                           log(lag_militaryexp) +
                                           log(lag_refugeeout) +
                                           lag_casualties +
                                           purpose +
                                           Contributor_EU +
                                           Contributor_AU +
                                           lag_ym_popgrwth_perc +
                                           New_Total +
                                           log(lag_tot+1) |
                                           sp_ind, 
                            vcov         = "iid",
                            data         = nested_authorized_data, 
                            panel.id     = ~ sp_ind
                            )

auth_mult_troops2 <- feols(
                           Smooth_Troops ~
                                           post +
                                           treat_democ +
                                           post:treat_democ +
                                           log(distance) +
                                           log(lag_militaryexp) +
                                           log(lag_refugeeout) +
                                           lag_casualties +
                                           purpose +
                                           Contributor_EU +
                                           Contributor_AU +
                                           lag_ym_popgrwth_perc +
                                           New_Total +
                                           log(lag_tot+1) |
                                           sp_ind, 
                            vcov         = "iid",
                            data         = nested_authorized_data, 
                            panel.id     = ~ sp_ind
                            )
                        # Authorization models for troops only

auth_mult_police1a <- feols(
                            Civilian_Police ~
                                              post +
                                              polity2 +
                                              post:polity2 +
                                              log(distance) +
                                              log(lag_militaryexp) +
                                              log(lag_refugeeout) +
                                              lag_casualties +
                                              purpose +
                                              Contributor_EU +
                                              Contributor_AU +
                                              lag_ym_popgrwth_perc +
                                              New_Total +
                                              log(lag_tot+1) +
                                              officially_authorized |
                                              sp_ind, 
                              vcov          = "iid",
                              data          = nested_authorized_data, 
                              panel.id      = ~ sp_ind
                              )

auth_mult_police2a <- feols(
                            Civilian_Police ~
                                              post +
                                              treat_democ +
                                              post:treat_democ +
                                              log(distance) +
                                              log(lag_militaryexp) +
                                              log(lag_refugeeout) +
                                              lag_casualties +
                                              purpose +
                                              Contributor_EU +
                                              Contributor_AU +
                                              lag_ym_popgrwth_perc +
                                              New_Total +
                                              log(lag_tot+1) +
                                              officially_authorized |
                                              sp_ind, 
                             vcov           = "iid",
                             data           = nested_authorized_data, 
                             panel.id       = ~ sp_ind
                             )

auth_mult_polices1a <- feols(
                             Smooth_Police ~
                                             post +
                                             polity2 +
                                             post:polity2 +
                                             log(distance) +
                                             log(lag_militaryexp) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose +
                                             Contributor_EU +
                                             Contributor_AU +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1)+ officially_authorized |
                                             sp_ind, 
                              vcov         = "iid",
                              data         = nested_authorized_data, 
                              panel.id     = ~ sp_ind
                              )

auth_mult_polices2a <- feols(
                             Smooth_Police ~
                                             post +
                                             treat_democ +
                                             post:treat_democ +
                                             log(distance) +
                                             log(lag_militaryexp) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose +
                                             Contributor_EU +
                                             Contributor_AU +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) +
                                             officially_authorized |
                                             sp_ind, 
                              vcov         = "iid",
                              data         = nested_authorized_data, 
                              panel.id     = ~ sp_ind
                              )

auth_mult_police1 <- feols(
                           Civilian_Police ~
                                             post +
                                             polity2 +
                                             post:polity2 +
                                             log(distance) +
                                             log(lag_militaryexp) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose +
                                             Contributor_EU +
                                             Contributor_AU +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) |
                                             sp_ind, 
                            vcov           = "iid",
                            data           = nested_authorized_data, 
                            panel.id       = ~ sp_ind
                            )

auth_mult_police2 <- feols(
                           Civilian_Police ~
                                             post +
                                             treat_democ +
                                             post:treat_democ +
                                             log(distance) +
                                             log(lag_militaryexp) +
                                             log(lag_refugeeout) +
                                             lag_casualties +
                                             purpose +
                                             Contributor_EU +
                                             Contributor_AU +
                                             lag_ym_popgrwth_perc +
                                             New_Total +
                                             log(lag_tot+1) |
                                             sp_ind, 
                            vcov           = "iid",
                            data           = nested_authorized_data, 
                            panel.id       = ~ sp_ind
                            )

auth_mult_polices1 <- feols(
                            Smooth_Police ~
                                            post +
                                            polity2 +
                                            post:polity2 +
                                            log(distance) +
                                            log(lag_militaryexp) +
                                            log(lag_refugeeout) +
                                            lag_casualties +
                                            purpose +
                                            Contributor_EU +
                                            Contributor_AU +
                                            lag_ym_popgrwth_perc +
                                            New_Total +
                                            log(lag_tot+1) |
                                            sp_ind, 
                             vcov         = "iid",
                             data         = nested_authorized_data,
                             panel.id     = ~ sp_ind
                             )

auth_mult_polices2 <- feols(
                            Smooth_Police ~
                                            post +
                                            treat_democ +
                                            post:treat_democ +
                                            log(distance) +
                                            log(lag_militaryexp) +
                                            log(lag_refugeeout) +
                                            lag_casualties +
                                            purpose +
                                            Contributor_EU +
                                            Contributor_AU +
                                            lag_ym_popgrwth_perc +
                                            New_Total +
                                            log(lag_tot+1) |
                                            sp_ind, 
                             vcov         = "iid",
                             data         = nested_authorized_data, 
                             panel.id     = ~ sp_ind
                             )
                        # Authorization models for police only

auth_mult_Observer1a <- feols(
                              Observers ~
                                          post +
                                          polity2 +
                                          post:polity2 +
                                          log(distance) +
                                          log(lag_militaryexp) +
                                          log(lag_refugeeout) +
                                          lag_casualties +
                                          purpose +
                                          Contributor_EU +
                                          Contributor_AU +
                                          lag_ym_popgrwth_perc +
                                          New_Total +
                                          log(lag_tot+1) +
                                           officially_authorized |
                                           sp_ind, 
                                vcov     = "iid",
                                data     = nested_authorized_data, 
                                panel.id = ~ sp_ind
                                )

auth_mult_Observer2a <- feols(
                              Observers ~
                                          post +
                                          treat_democ +
                                          post:treat_democ +
                                          log(distance) +
                                          log(lag_militaryexp) +
                                          log(lag_refugeeout) +
                                          lag_casualties +
                                          purpose +
                                          Contributor_EU +
                                          Contributor_AU +
                                          lag_ym_popgrwth_perc +
                                          New_Total +
                                          log(lag_tot+1) +
                                          officially_authorized |
                                          sp_ind, 
                               vcov     = "iid",
                               data     = nested_authorized_data, 
                               panel.id = ~ sp_ind
                               )

auth_mult_Observers1a <- feols(
                               Smooth_Observers ~
                                                  post +
                                                  polity2 +
                                                  post:polity2 +
                                                  log(distance) +
                                                  log(lag_militaryexp) +
                                                  log(lag_refugeeout) +
                                                  lag_casualties +
                                                  purpose +
                                                  Contributor_EU +
                                                  Contributor_AU +
                                                  lag_ym_popgrwth_perc +
                                                  New_Total +
                                                  log(lag_tot+1)+ officially_authorized |
                                                  sp_ind, 
                                vcov            = "iid",
                                data            = nested_authorized_data, 
                                panel.id        = ~ sp_ind
                                )

auth_mult_Observers2a <- feols(
                               Smooth_Observers ~
                                                  post +
                                                  treat_democ +
                                                  post:treat_democ +
                                                  log(distance) +
                                                  log(lag_militaryexp) +
                                                  log(lag_refugeeout) +
                                                  lag_casualties +
                                                  purpose +
                                                  Contributor_EU +
                                                  Contributor_AU +
                                                  lag_ym_popgrwth_perc +
                                                  New_Total +
                                                  log(lag_tot+1) +
                                                  officially_authorized |
                                                  sp_ind, 
                                vcov            = "iid",
                                data            = nested_authorized_data, 
                                panel.id        = ~ sp_ind
                                )

auth_mult_Observer1 <- feols(
                             Observers ~
                                         post +
                                         polity2 +
                                         post:polity2 +
                                         log(distance) +
                                         log(lag_militaryexp) +
                                         log(lag_refugeeout) +
                                         lag_casualties +
                                         purpose +
                                         Contributor_EU +
                                         Contributor_AU +
                                         lag_ym_popgrwth_perc +
                                         New_Total +
                                         log(lag_tot+1) |
                                         sp_ind, 
                              vcov     = "iid",
                              data     = nested_authorized_data, 
                              panel.id = ~ sp_ind
                              )

auth_mult_Observer2 <- feols(
                             Observers ~
                                         post +
                                         treat_democ +
                                         post:treat_democ +
                                         log(distance) +
                                         log(lag_militaryexp) +
                                         log(lag_refugeeout) +
                                         lag_casualties +
                                         purpose +
                                         Contributor_EU +
                                         Contributor_AU +
                                         lag_ym_popgrwth_perc +
                                         New_Total +
                                         log(lag_tot+1) |
                                         sp_ind, 
                              vcov     = "iid",
                              data     = nested_authorized_data, 
                              panel.id = ~ sp_ind
                              )

auth_mult_Observers1 <- feols(
                              Smooth_Observers ~
                                                 post +
                                                 polity2 +
                                                 post:polity2 +
                                                 log(distance) +
                                                 log(lag_militaryexp) +
                                                 log(lag_refugeeout) +
                                                 lag_casualties +
                                                 purpose +
                                                 Contributor_EU +
                                                 Contributor_AU +
                                                 lag_ym_popgrwth_perc +
                                                 New_Total +
                                                 log(lag_tot+1) |
                                                 sp_ind, 
                               vcov            = "iid",
                               data            = nested_authorized_data, 
                               panel.id        = ~ sp_ind
                               )

auth_mult_Observers2 <- feols(
                              Smooth_Observers ~
                                                 post +
                                                 treat_democ +
                                                 post:treat_democ +
                                                 log(distance) +
                                                 log(lag_militaryexp) +
                                                 log(lag_refugeeout) +
                                                 lag_casualties +
                                                 purpose +
                                                 Contributor_EU +
                                                 Contributor_AU +
                                                 lag_ym_popgrwth_perc +
                                                 New_Total +
                                                 log(lag_tot+1) |
                                                 sp_ind, 
                               vcov            = "iid",
                               data            = nested_authorized_data, 
                               panel.id        = ~ sp_ind
                               )
                        # Authorization models for observers only

#############
# Table A11 #
#############

print(auth_df)

#############
# Table A12 #
#############

screenreg(
          list(
               Authtotal_cont,
               Authtotal_bin,
               Authsmooth_total_cont,
               Authsmooth_total_bin,
               Authtotal_cont2,
               Authtotal_bin2,
               Authsmooth_total_cont2,
               Authsmooth_total_bin2
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (Authorization cont., continuous democracy)",
                                 "Count of peacekeepers (Authorization cont., continuous democracy)",
                                 "Count of peacekeepers (Authorization not cont., binary democracy)",
                                 "Count of peacekeepers (Authorization not cont., binary democracy)",
                                 "Count of peacekeepers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of peacekeepers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of peacekeepers (Authorization not cont., smoothed, binary democracy)",
                                 "Count of peacekeepers (Authorization not cont., smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Authorized personnel",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 4 : 6,
                                 3
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#############
# Table A13 #
#############

screenreg(
          list(
               auth_mult_total1a,
               auth_mult_total2a,
               auth_mult_totals1a,
               auth_mult_totals2a,
               auth_mult_total1,
               auth_mult_total2,
               auth_mult_totals1,
               auth_mult_totals2
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of peacekeepers (Authorization cont., continuous democracy)",
                                 "Count of peacekeepers (Authorization cont., continuous democracy)",
                                 "Count of peacekeepers (Authorization not cont., binary democracy)",
                                 "Count of peacekeepers (Authorization not cont., binary democracy)",
                                 "Count of peacekeepers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of peacekeepers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of peacekeepers (Authorization not cont., smoothed, binary democracy)",
                                 "Count of peacekeepers (Authorization not cont., smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Authorized personnel",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#############
# Table A14 #
#############

screenreg(
          list(
               auth_mult_troop1a,
               auth_mult_troop2a,
               auth_mult_troops1a,
               auth_mult_troops2a,
               auth_mult_troop1,
               auth_mult_troop2,
               auth_mult_troops1,
               auth_mult_troops2
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of soldiers (Authorization cont., continuous democracy)",
                                 "Count of soldiers (Authorization cont., continuous democracy)",
                                 "Count of soldiers (Authorization not cont., binary democracy)",
                                 "Count of soldiers (Authorization not cont., binary democracy)",
                                 "Count of soldiers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of soldiers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of soldiers (Authorization not cont., smoothed, binary democracy)",
                                 "Count of soldiers (Authorization not cont., smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Authorized personnel",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#############
# Table A15 #
#############

screenreg(
          list(
               auth_mult_police1a,
               auth_mult_police2a,
               auth_mult_polices1a,
               auth_mult_polices2a,
               auth_mult_police1,
               auth_mult_police2,
               auth_mult_polices1,
               auth_mult_polices2
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of police (Authorization cont., continuous democracy)",
                                 "Count of police (Authorization cont., continuous democracy)",
                                 "Count of police (Authorization not cont., binary democracy)",
                                 "Count of police (Authorization not cont., binary democracy)",
                                 "Count of police (Authorization cont., smoothed, continuous democracy)",
                                 "Count of police (Authorization cont., smoothed, continuous democracy)",
                                 "Count of police (Authorization not cont., smoothed, binary democracy)",
                                 "Count of police (Authorization not cont., smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Authorized personnel",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )

#############
# Table A16 #
#############

screenreg(
          list(
               auth_mult_Observer1a,
               auth_mult_Observer2a,
               auth_mult_Observers1a,
               auth_mult_Observers2a,
               auth_mult_Observer1,
               auth_mult_Observer2,
               auth_mult_Observers1,
               auth_mult_Observers2
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Count of observers (Authorization cont., continuous democracy)",
                                 "Count of observers (Authorization cont., continuous democracy)",
                                 "Count of observers (Authorization not cont., binary democracy)",
                                 "Count of observers (Authorization not cont., binary democracy)",
                                 "Count of observers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of observers (Authorization cont., smoothed, continuous democracy)",
                                 "Count of observers (Authorization not cont., smoothed, binary democracy)",
                                 "Count of observers (Authorization not cont., smoothed, binary democracy)"
                                 ),
          custom.coef.names  = c(
                                 "Post-election",
                                 "Polity score",
                                 "Military expenditures",
                                 "Refugees",
                                 "Casualties",
                                 "Population growth",
                                 "New missions",
                                 "Total violence",
                                 "Authorized personnel",
                                 "Polity x post-election",
                                 "Democracy",
                                 "Democracy x post-election"
                                 ),
          reorder.coef       = c(
                                 1 : 2,
                                 10 : 12,
                                 3 : 9
                                 ),
          include.groups     = FALSE,
          include.rsq        = FALSE,
          include.proj.stats = FALSE,
          custom.gof.names   = c(
                                 "Number of Observations",
                                 "Adjusted R^2"
                                 )
          )
