+---------------------------------------------+
| This file contains instructions for         |
| replicating the analysis in:                |
|                                             |
| "Election Accomplished: Democracies and the |
| Timing of Peacekeeper Drawdowns             |    
|                                             |
| By Burak Giray and J. Tyson Chatagnier      |
|                                             |
| Forthcoming in Political Research Quarterly |
|                                             |
| File created 9 July 2023                    |
+---------------------------------------------+

Contents
=========

 * ea_online_appendix.pdf
   - PDF containing supplementary information and additional analyses not presented in the body of the article
 * election_accomplished_replication_code.R
   - R file used to replicate the results from the body of the article (lines 1--577) and the appendix (lines 578--3342)
 * mission_level_replication_data.csv
   - Comma-separated values file, containing necessary information to replicate the mission-level analyses in the main text and appendix
 * tcc_level_replication_data.csv
   - Comma-separated values file, containing necessary information to replicate the contributor-level analyses in the main text and appendix

Necessary Software
==================

 * R (analysis performed on R for Windows, v. 4.2.2)
 * R packages:
   - texreg
   - plm
   - fixest
   - marginaleffects
   - readr
   - tidyverse
   - gridExtra

Instructions
=============

1. Extract files to the relevant directory
2. Open election_accomplished_replication_code.R and insert directory information if necessary
3. Run file to replicate results (output will appear on screen)